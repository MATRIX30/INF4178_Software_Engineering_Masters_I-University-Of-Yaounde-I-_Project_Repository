const mysql = require("mysql2");
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'smallholder'
});

exports.view = (req, res) => {
  if (req.session.userId) {
    // Session active, continuer le traitement pour afficher le dashboard personnalisé
    // Récupérer les données nécessaires depuis la base de données
    db.query('SELECT * FROM taches WHERE user_id = ?', [req.session.userId], (error, results) => {
      if (error) {
        console.log(error);
        res.status(500).json({ message: 'Erreur lors de la récupération des données du dashboard' });
      } else {
        // Utiliser les résultats pour afficher le dashboard personnalisé
        console.log(results)
        res.render('todolist', { taches: results[1] });
      }
    });
  } 
};

exports.store = (req, res) => {
  const {nom_tache, duree_tache, repetition, jour_repetition, heure_repetition, description_tache, date_tache, date_debut, date_fin, statut_tache} = req.body;

    let id = req.session.userId;
    if(id){
      console.log("ok")
        db.query("INSERT INTO taches SET ?", {
          user_id:id, 
          nom_tache:nom_tache, 
          duree_tache:duree_tache, 
          repetition:repetition, 
          jour_repetition:jour_repetition, 
          heure_repetition:heure_repetition, 
          description_tache:description_tache, 
          date_tache:date_tache, 
          date_debut:date_debut, 
          date_fin:date_fin, 
          statut_tache:statut_tache
        }, (error, results) =>{
          console.log("ok")
            if(error){
                console.log(error);
            }else{
                db.query("SELECT * FROM taches WHERE user_id = ?",[id], (error, results) =>{
                    if(error){
                        console.log(error);
                    }else{
                        // req.session.userId = user.id;
                        return res.redirect("/todolist");
                    }
                })
               
            }
        });
   
    }else{console.log("erreur de code")}
  
   
};

// // Autres fonctions pour la suppression ou la modification des tâches peuvent être ajoutées ici

