const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'smallholder'
});


exports.register = (req, res) =>{
    const nom = req.body.nom;
    const prenom = req.body.prenom;
    const email = req.body.email;
    const motDePasse = req.body.motDePasse;
    const confirmeMotDePasse = req.body.confirmeMotDePasse;
    const accept = req.body.accept;

    if(!accept){
        return res.render('register', {
            message: 'vous devez accepter nos politiques'
        });
    }else{
            db.query("SELECT email from utilisateurs WHERE email = ?", [email], async (error, results) =>{
                if(error){
                    console.log(error);
                }
                if(results.length > 0){
                    return res.render('register', {
                        message: 'un utilisateur ayant cette email existe deja'
                    });
                }else if(motDePasse!==confirmeMotDePasse){
                    return res.render('register', {
                        message: 'les deux mots de passe sont incorrectent'
                    });
                }
                
                let hashedPassword = await bcrypt.hash(motDePasse, 8);
                console.log(hashedPassword);
                db.query("INSERT INTO utilisateurs SET ?", {nom: nom, prenom: prenom, email: email, motDePasse: hashedPassword}, (error, results) =>{
                    if(error){
                        console.log(error);
                    }else{
                        db.query("SELECT * FROM utilisateurs WHERE email = ?"[email], (error, results) =>{
                            if(error){
                                console.log(error);
                            }else{
                                req.session.userId = user.id;
                                return res.redirect("/dashboard");
                            }
                        })
                       
                    }
                });
            });
        }
    }

    exports.login = (req, res) => {
        const { email, password, remember } = req.body;
      
        db.query("SELECT * FROM utilisateurs WHERE email= ?", [email], async (error, results) => {
          if (error) {
            console.log(error);
            res.status(500).json({ message: 'Erreur lors de la connexion' });
          } else {
            if (results.length > 0) {
              const user = results[0];
              console.log(bcrypt.compare(password, user.motDePasse));
              bcrypt.compare(password, user.motDePasse, (err, isMatch) => {
                if (err) {
                  console.log(err);
                  return res.render('login', { message: 'Erreur lors de la comparaison des mots de passe' });
                } else {
                  if (isMatch) {
                    req.session.userId = user.id; // Stockez l'ID de l'utilisateur dans la session
                    req.session.email = user.email;
                    res.redirect("/dashboard");
                    console.log("ok!", req.session.userId)
                  } else {
                    return res.render('login', { message: 'Identifiants invalides' });
                  }
                }
              });
            } else {
             return res.render('login',{ message: 'Identifiants invalides' });
            }
          }
        });
      };
      
      exports.logout = (req, res) =>{
        req.session = null; // Supprimez la session en réinitialisant son contenu
       return  res.redirect('/'); // Redirigez l'utilisateur vers la page de connexion
      }