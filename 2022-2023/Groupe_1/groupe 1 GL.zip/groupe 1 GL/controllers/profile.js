const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'smallholder'
});



exports.profile = (req, res) =>{
    db.connect((error) =>{
        if(error){
            console.log(error)
        }else{
            console.log("db connected successefulling");
        }
    })
    

    if (req.session.userId ) {
        // Session active, continuer le traitement pour afficher le dashboard personnalisé
        // Récupérer les données nécessaires depuis la base de données
        db.query('SELECT * FROM utilisateurs WHERE id = ?', [req.session.userId], (error, results) => {
          if (error) {
            console.log(error);
            res.status(500).json({ message: 'Erreur lors de la récupération des données du dashboard' });
          } else {
            // Utiliser les résultats pour afficher le dashboard personnalisé
            res.render('profile', { user: results[0] });
          }
        });
      } else {
        // Pas de session active, rediriger vers la page de connexion
        res.redirect('/dashboard');
      }
}

exports.view = (req, res) =>{
    db.connect((error) =>{
        if(error){
            console.log(error)
        }else{
            console.log("db connected successefulling");
        }
    })
    
    let id = req.params.id;
    if(id){
        db.query("SELECT * from utilisateurs WHERE id = ?", [id], async (error, results) =>{
            if(error){
                console.log(error);
            }
            if(results.length > 0){
                return res.render('addProfile',{user: results[0] });
            }
        });
    }else{console.log('recuperer le id')}
    

    
}

exports.update = (req, res) =>{
   
    
    const {nom, prenom, email, genre, adresse, telephone,  date_naissance, experience, domaine_activites, certification } = req.body;
    let id = req.params.id;
    db.query("SELECT id FROM utilisateurs WHERE id = ?", [id], async (error, results) => {
        if (error) {
            console.log(error);
        }
        if (results.length > 0) {
            db.query("SELECT * FROM utilisateurs WHERE email = ?", [email], (error, existingUsers) => {
                if (error) {
                    console.log(error);
                } else {
                    if (existingUsers.length > 0 && existingUsers[0].id !== id) {
                        // L'adresse e-mail existe déjà pour un autre utilisateur
                        console.log("Adresse e-mail déjà utilisée");
                        db.query("UPDATE utilisateurs SET ? WHERE id = ?", [{ nom, prenom,  genre, date_naissance, telephone, domaine_activites, adresse, experience, certification }, id], (error, results) => {
                            if (error) {
                                console.log(error);
                            } else {
                                req.session.userId = id;
                                return res.redirect("/profile");
                            }
                        });
                    } else {
                        db.query("UPDATE utilisateurs SET ? WHERE id = ?", [{ nom, prenom,  genre, date_naissance, telephone, domaine_activites, adresse, experience, certification }, id], (error, results) => {
                            if (error) {
                                console.log(error);
                            } else {
                                req.session.userId = id;
                                return res.redirect("/profile");
                            }
                        });
                    }
                }
            });
        }
    });
    


   
}