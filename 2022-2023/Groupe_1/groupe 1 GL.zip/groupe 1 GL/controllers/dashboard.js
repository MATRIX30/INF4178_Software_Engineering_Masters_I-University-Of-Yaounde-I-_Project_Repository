const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'smallholder'
});

exports.dashboard = (req, res) =>{
  // console.log("ok!", req.session.userId);
    if (req.session.userId && req.session.email) {
        // Session active, continuer le traitement pour afficher le dashboard personnalisé
        // Récupérer les données nécessaires depuis la base de données
        db.query('SELECT * FROM utilisateurs WHERE id = ?', [req.session.userId], (error, results) => {
          if (error) {
            console.log(error);
            res.status(500).json({ message: 'Erreur lors de la récupération des données du dashboard' });
          } else {
            // Utiliser les résultats pour afficher le dashboard personnalisé
            res.render('dashboard', { user: results[0] });
          }
        });
      } else {
        // Pas de session active, rediriger vers la page de connexion
        res.redirect('/login');
      }
}