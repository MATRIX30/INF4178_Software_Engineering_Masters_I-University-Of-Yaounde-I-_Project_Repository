const express = require("express");

const mysql = require("mysql2");

const dotenv = require("dotenv");

const path = require('path'); 

dotenv.config({path: '/.env'});

const cookieSession = require('cookie-session');

const exphbs = require('express-handlebars');

const app = express();

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'smallholder'
});

const publicDirectory = path.join(__dirname, './public');

app.use(express.static(publicDirectory));

// Configuration de la session avec cookie-session
app.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2'], // Changez ces clés secrètes avec vos propres clés
    maxAge: 24 * 60 * 60 * 1000 // Durée de validité du cookie (1 jour ici)
}));

app.use(express.urlencoded({extended: false}));
app.use(express.json());

// app.engine('hbs', exphbs({ extname: '.hbs' }));

app.set("view engine", 'hbs');
db.connect((error) =>{
    if(error){
        console.log(error)
    }else{
        console.log("db connected successefulling");
    }
})

app.use("/", require("./routes/pages"));
app.use("/auth", require("./routes/auth"));
app.use("/profile", require("./routes/profile"));
app.use("/todolist", require("./routes/todolist"));
app.get('/logout', (req, res) => {
    req.session = null; // Supprimez la session en réinitialisant son contenu
    res.render('index',{
        message: 'Merci d\'avoir utilisé notre service à très bientôt'
    }); // Redirigez l'utilisateur vers la page de connexion
  });

app.listen(5000, () =>{
    console.log("serveur started on port 5000");
})