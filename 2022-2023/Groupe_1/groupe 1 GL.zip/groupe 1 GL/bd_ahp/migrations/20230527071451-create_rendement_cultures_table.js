'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('RendementCultures', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      description: {
        type: Sequelize.STRING,
        allowNull: true
      },
      date_rendement_culture: {
        type: Sequelize.DATE,
        allowNull: false
      },
      quantite_rendement_obtenu: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      id_culture: {
        type: Sequelize.INTEGER,
        allowNull: false,
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      id_parcelle_occupee: {
        type: Sequelize.INTEGER,
        allowNull: false,
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    await queryInterface.addConstraint('RendementCultures', {
      fields: ['id_culture'],
      type: 'foreign key',
      name: 'fk_rendement_cultures_culture',
      references: {
        table: 'Cultures',
        field: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE'
    });

    await queryInterface.addConstraint('RendementCultures', {
      fields: ['id_parcelle_occupee'],
      type: 'foreign key',
      name: 'fk_rendement_cultures_parcelle',
      references: {
        table: 'Parcelles',
        field: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE'
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('RendementCultures', 'fk_rendement_cultures_culture');
    await queryInterface.removeConstraint('RendementCultures', 'fk_rendement_cultures_parcelle');
    await queryInterface.dropTable('RendementCultures');
  }
};
