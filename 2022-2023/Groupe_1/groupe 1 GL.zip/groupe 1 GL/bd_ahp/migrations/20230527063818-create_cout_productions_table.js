'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Cout_productions', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      description: {
        type: Sequelize.STRING,
        allowNull: true
      },
      type_cout: {
        type: Sequelize.STRING,
        allowNull: false
      },
      Montant: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      id_culture: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Cultures',
          key: 'id'
        }
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    await queryInterface.addConstraint('Cout_productions', {
      fields: ['id_culture'],
      type: 'foreign key',
      name: 'fk_cout_productions_culture',
      references: {
        table: 'Cultures',
        field: 'id'
      },
      onDelete: 'cascade',
      onUpdate: 'cascade'
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('Cout_productions', 'fk_cout_productions_culture');
    await queryInterface.dropTable('Cout_productions');
  }
};
