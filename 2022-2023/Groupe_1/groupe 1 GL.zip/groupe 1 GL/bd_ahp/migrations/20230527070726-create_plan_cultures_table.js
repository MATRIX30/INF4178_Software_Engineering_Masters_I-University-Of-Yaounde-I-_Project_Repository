'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('PlanCultures', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      date_debut_culture: {
        type: Sequelize.DATE
      },
      date_fin_culture: {
        type: Sequelize.DATE
      },
      description: {
        type: Sequelize.STRING
      },
      quantite_semence: {
        type: Sequelize.FLOAT
      },
      parcelle_terre_occupe: {
        type: Sequelize.STRING
      },
      id_culture: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Cultures',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('PlanCultures');
  }
};
