'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Prevision_recoltes', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      id_culture: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Cultures',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      parcelle_terre_occupe: {
        type: Sequelize.STRING,
        allowNull: false
      },
      date_recolte_estimee: {
        type: Sequelize.DATE,
        allowNull: false
      },
      volume_recolte_prevu: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Prevision_recoltes');
  }
};
