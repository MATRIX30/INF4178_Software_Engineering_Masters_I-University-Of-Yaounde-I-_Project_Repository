'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Parcelles', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      nom_parcelle: {
        type: Sequelize.STRING,
        allowNull: false
      },
      longeur: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      largeur: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      qualite_parcelle: {
        type: Sequelize.STRING,
        allowNull: false
      },
      description: {
        type: Sequelize.STRING,
        allowNull: true
      },
      disponibilite_parcelle: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      emplacement_geographique: {
        type: Sequelize.STRING,
        allowNull: false
      },
      id_main_oeuvre: {
        type: Sequelize.INTEGER,
        allowNull: false,
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    await queryInterface.addConstraint('Parcelles', {
      fields: ['id_main_oeuvre'],
      type: 'foreign key',
      name: 'fk_parcelles_main_oeuvre',
      references: {
        table: 'MainDOeuvres',
        field: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE'
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('Parcelles', 'fk_parcelles_main_oeuvre');
    await queryInterface.dropTable('Parcelles');
  }
};
