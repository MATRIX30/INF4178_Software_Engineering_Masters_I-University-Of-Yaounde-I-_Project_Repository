'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Conseil_recommandations', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      nom_conseil: {
        type: Sequelize.STRING,
        allowNull: false
      },
      contenu_conseil: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      id_ravageur: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Ravageurs',
          key: 'id'
        }
      },
      id_maladie: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Maladies',
          key: 'id'
        }
      },
      id_culture: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Cultures',
          key: 'id'
        }
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    await queryInterface.addConstraint('Conseil_recommandations', {
      fields: ['id_ravageur'],
      type: 'foreign key',
      name: 'fk_conseil_recommandations_ravageur',
      references: {
        table: 'Ravageurs',
        field: 'id'
      },
      onDelete: 'cascade',
      onUpdate: 'cascade'
    });

    await queryInterface.addConstraint('Conseil_recommandations', {
      fields: ['id_maladie'],
      type: 'foreign key',
      name: 'fk_conseil_recommandations_maladie',
      references: {
        table: 'Maladies',
        field: 'id'
      },
      onDelete: 'cascade',
      onUpdate: 'cascade'
    });

    await queryInterface.addConstraint('Conseil_recommandations', {
      fields: ['id_culture'],
      type: 'foreign key',
      name: 'fk_conseil_recommandations_culture',
      references: {
        table: 'Cultures',
        field: 'id'
      },
      onDelete: 'cascade',
      onUpdate: 'cascade'
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('Conseil_recommandations', 'fk_conseil_recommandations_ravageur');
    await queryInterface.removeConstraint('Conseil_recommandations', 'fk_conseil_recommandations_maladie');
    await queryInterface.removeConstraint('Conseil_recommandations', 'fk_conseil_recommandations_culture');
    await queryInterface.dropTable('Conseil_recommandations');
  }
};
