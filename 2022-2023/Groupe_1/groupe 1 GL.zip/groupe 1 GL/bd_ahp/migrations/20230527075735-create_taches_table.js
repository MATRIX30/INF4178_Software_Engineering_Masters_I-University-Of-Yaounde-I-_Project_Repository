'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Taches', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      nom_tache: {
        type: Sequelize.STRING
      },
      duree_tache: {
        type: Sequelize.INTEGER
      },
      repetition: {
        type: Sequelize.BOOLEAN
      },
      jour_repetition: {
        type: Sequelize.STRING
      },
      heure_repetition: {
        type: Sequelize.STRING
      },
      description_tache: {
        type: Sequelize.STRING
      },
      date_tache: {
        type: Sequelize.DATE
      },
      date_debut: {
        type: Sequelize.DATE
      },
      date_fin: {
        type: Sequelize.DATE
      },
      statut_tache: {
        type: Sequelize.STRING
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Taches');
  }
};
