'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Historique_activites', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      id_agriculteur: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Agriculteurs',
          key: 'id'
        },
        allowNull: false
      },
      action: {
        type: Sequelize.STRING
      },
      date_heure: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
      },
      detail: {
        type: Sequelize.STRING
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Historique_activites');
  }
};
