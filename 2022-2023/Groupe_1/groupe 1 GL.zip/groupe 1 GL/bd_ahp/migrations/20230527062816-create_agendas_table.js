'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Agendas', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      nom: {
        type: Sequelize.STRING,
        allowNull: false
      },
      description: {
        type: Sequelize.STRING,
        allowNull: true
      },
      id_plan_culture: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'PlanCultures',
          key: 'id'
        }
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    await queryInterface.addConstraint('Agendas', {
      fields: ['id_plan_culture'],
      type: 'foreign key',
      name: 'fk_agendas_plan_culture',
      references: {
        table: 'PlanCultures',
        field: 'id'
      },
      onDelete: 'cascade',
      onUpdate: 'cascade'
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('Agendas', 'fk_agendas_plan_culture');
    await queryInterface.dropTable('Agendas');
  }
};
