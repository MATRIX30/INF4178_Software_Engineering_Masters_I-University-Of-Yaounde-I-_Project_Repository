'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Cultures', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      nom_culture: {
        type: Sequelize.STRING
      },
      variete_culture: {
        type: Sequelize.STRING
      },
      description: {
        type: Sequelize.STRING
      },
      date_plantation: {
        type: Sequelize.DATE
      },
      type_culture: {
        type: Sequelize.STRING
      },
      condition_croissance_culture: {
        type: Sequelize.STRING
      },
      besoins_arrosage: {
        type: Sequelize.STRING
      },
      methode_culture: {
        type: Sequelize.STRING
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Cultures');
  }
};
