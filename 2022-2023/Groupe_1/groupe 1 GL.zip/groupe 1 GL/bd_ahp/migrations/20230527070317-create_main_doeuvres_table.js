'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('MainDOeuvres', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      id_culture: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Cultures',
          key: 'id',
        },
        allowNull: false,
      },
      nom_responsable: {
        type: Sequelize.STRING,
      },
      tel_responsable: {
        type: Sequelize.STRING,
      },
      sexe_main_oeuvre: {
        type: Sequelize.STRING,
      },
      saison_travail: {
        type: Sequelize.STRING,
      },
      nom_main_oeuvre: {
        type: Sequelize.STRING,
      },
      prenom_main_oeuvre: {
        type: Sequelize.STRING,
      },
      poste_main_oeuvre: {
        type: Sequelize.STRING,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('MainDOeuvres');
  }
};
