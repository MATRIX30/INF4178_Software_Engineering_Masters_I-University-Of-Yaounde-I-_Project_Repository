const express = require('express');
const router = express.Router();
const IntrantAgricoleController = require('../controllers/IntrantAgricoleController');

const intrantAgricoleController = new IntrantAgricoleController();

router.get('/', intrantAgricoleController.getAllIntrantsAgricoles);
router.get('/:id', intrantAgricoleController.getIntrantAgricoleById);
router.post('/', intrantAgricoleController.createIntrantAgricole);
router.put('/:id', intrantAgricoleController.updateIntrantAgricole);
router.delete('/:id', intrantAgricoleController.deleteIntrantAgricole);

module.exports = router;
