import { Router } from 'express';
import AgendaController from '../controllers/AgendaController.js';

const router = Router();
 const agendaController = new AgendaController();

// Route pour obtenir tous les agendas
router.get('/', AgendaController.getAllAgendas.bind(agendaController));

// Route pour obtenir un agenda par son ID
router.get('/:id', AgendaController.getAgendaById.bind(agendaController));

// Route pour créer un nouvel agenda
router.post('/', AgendaController.createAgenda.bind(agendaController));

// Route pour mettre à jour un agenda existant
router.put('/:id', AgendaController.updateAgenda.bind(agendaController));

// Route pour supprimer un agenda
router.delete('/:id', AgendaController.deleteAgenda.bind(agendaController));

export default router;
