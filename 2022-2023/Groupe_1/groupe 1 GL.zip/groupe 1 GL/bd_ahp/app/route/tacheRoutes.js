const express = require('express');
const TacheController = require('../controllers/TacheController');

const router = express.Router();
const tacheController = new TacheController();

// GET /taches
router.get('/', tacheController.getAllTaches.bind(tacheController));

// GET /taches/:id
router.get('/:id', tacheController.getTacheById.bind(tacheController));

// POST /taches
router.post('/', tacheController.createTache.bind(tacheController));

// PUT /taches/:id
router.put('/:id', tacheController.updateTache.bind(tacheController));

// DELETE /taches/:id
router.delete('/:id', tacheController.deleteTache.bind(tacheController));

module.exports = router;
