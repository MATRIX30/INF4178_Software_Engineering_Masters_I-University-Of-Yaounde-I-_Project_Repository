const express = require('express');
const MainDOeuvreController = require('./controllers/MainDOeuvreController');

const router = express.Router();

// GET /maindoeuvres
router.get('/maindoeuvres', MainDOeuvreController.getAllMainDOeuvres);

// GET /maindoeuvres/:id
router.get('/maindoeuvres/:id', MainDOeuvreController.getMainDOeuvreById);

// POST /maindoeuvres
router.post('/maindoeuvres', MainDOeuvreController.createMainDOeuvre);

// PUT /maindoeuvres/:id
router.put('/maindoeuvres/:id', MainDOeuvreController.updateMainDOeuvre);

// DELETE /maindoeuvres/:id
router.delete('/maindoeuvres/:id', MainDOeuvreController.deleteMainDOeuvre);

module.exports = router;
