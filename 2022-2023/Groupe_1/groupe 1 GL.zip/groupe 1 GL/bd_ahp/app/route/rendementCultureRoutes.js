const express = require('express');
const router = express.Router();
const RendementCultureController = require('../controllers/RendementCultureController');

const rendementCultureController = new RendementCultureController();

// Route GET pour récupérer tous les rendements des cultures
router.get('/', rendementCultureController.getAllRendementsCultures);

// Route GET pour récupérer un rendement de culture par son identifiant
router.get('/:id', rendementCultureController.getRendementCultureById);

// Route POST pour créer un nouveau rendement de culture
router.post('/', rendementCultureController.createRendementCulture);

// Route PUT pour mettre à jour un rendement de culture existant
router.put('/:id', rendementCultureController.updateRendementCulture);

// Route DELETE pour supprimer un rendement de culture par son identifiant
router.delete('/:id', rendementCultureController.deleteRendementCulture);

module.exports = router;
