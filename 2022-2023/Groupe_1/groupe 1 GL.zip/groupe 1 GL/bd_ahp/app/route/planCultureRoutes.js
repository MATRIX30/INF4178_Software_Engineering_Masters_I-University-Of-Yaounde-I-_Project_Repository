const express = require('express');
const router = express.Router();
const PlanCultureController = require('../controllers/PlanCultureController');

const planCultureController = new PlanCultureController();

router.get('/', planCultureController.getAllPlans.bind(planCultureController));
router.get('/:id', planCultureController.getPlanById.bind(planCultureController));
router.post('/', planCultureController.createPlan.bind(planCultureController));
router.put('/:id', planCultureController.updatePlan.bind(planCultureController));
router.delete('/:id', planCultureController.deletePlan.bind(planCultureController));

module.exports = router;
