import { Router } from 'express';
const router = Router();
import AgriculteurController from '../controllers/AgriculteurController.js';

// GET /agriculteurs - Récupérer tous les agriculteurs
router.get('/', AgriculteurController.getAllAgriculteurs);

// GET /agriculteurs/:id - Récupérer un agriculteur par son ID
router.get('/:id', AgriculteurController.getAgriculteurById);

// POST /agriculteurs - Créer un nouvel agriculteur
router.post('/', AgriculteurController.createAgriculteur);

// PUT /agriculteurs/:id - Mettre à jour un agriculteur
router.put('/:id', AgriculteurController.updateAgriculteur);

// DELETE /agriculteurs/:id - Supprimer un agriculteur
router.delete('/:id', AgriculteurController.deleteAgriculteur);

export default router;
