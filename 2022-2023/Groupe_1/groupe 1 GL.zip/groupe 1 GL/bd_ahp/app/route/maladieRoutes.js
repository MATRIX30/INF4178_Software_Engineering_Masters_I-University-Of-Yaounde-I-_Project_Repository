const express = require('express');
const router = express.Router();
const MaladieController = require('../controllers/MaladieController');

const maladieController = new MaladieController();

// Route pour récupérer toutes les maladies
router.get('/', maladieController.getAllMaladies);

// Route pour récupérer une maladie par son identifiant
router.get('/:id', maladieController.getMaladieById);

// Route pour créer une nouvelle maladie
router.post('/', maladieController.createMaladie);

// Route pour mettre à jour une maladie
router.put('/:id', maladieController.updateMaladie);

// Route pour supprimer une maladie
router.delete('/:id', maladieController.deleteMaladie);

module.exports = router;
