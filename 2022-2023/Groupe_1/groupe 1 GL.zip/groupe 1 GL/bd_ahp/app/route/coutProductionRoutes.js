const express = require('express');
const router = express.Router();
const CoutProductionController = require('../controllers/CoutProductionController');

const coutProductionController = new CoutProductionController();

// Route pour récupérer tous les coûts de production
router.get('/', coutProductionController.getAllCoutsProduction);

// Route pour récupérer un coût de production par son identifiant
router.get('/:id', coutProductionController.getCoutProductionById);

// Route pour créer un nouveau coût de production
router.post('/', coutProductionController.createCoutProduction);

// Route pour mettre à jour un coût de production existant
router.put('/:id', coutProductionController.updateCoutProduction);

// Route pour supprimer un coût de production par son identifiant
router.delete('/:id', coutProductionController.deleteCoutProduction);

module.exports = router;
