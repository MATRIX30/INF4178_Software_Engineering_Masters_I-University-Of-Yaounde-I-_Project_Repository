import { Router } from 'express';
const router = Router();
import ActiviteController from '../controllers/ActiviteController.js';


// const ActiviteController = new ActiviteController();

// Route pour récupérer toutes les activités
router.get('/', ActiviteController.getAllActivites);

// Route pour récupérer une activité par son ID
router.get('/:id', ActiviteController.getActiviteById);

// Route pour créer une nouvelle activité
router.post('/', ActiviteController.createActivite);

// Route pour mettre à jour une activité
router.put('/:id', ActiviteController.updateActivite);

// Route pour supprimer une activité
router.delete('/:id', ActiviteController.deleteActivite);

export default router;
