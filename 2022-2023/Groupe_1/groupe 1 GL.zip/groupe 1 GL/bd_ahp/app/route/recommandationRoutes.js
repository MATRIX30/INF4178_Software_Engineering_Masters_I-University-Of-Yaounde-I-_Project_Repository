const express = require('express');
const RecommandationController = require('../controllers/RecommandationController');

const router = express.Router();
const recommandationController = new RecommandationController();

// Route pour récupérer toutes les recommandations
router.get('/', recommandationController.getAllRecommandations);

// Route pour récupérer une recommandation par son identifiant
router.get('/:id', recommandationController.getRecommandationById);

// Route pour créer une nouvelle recommandation
router.post('/', recommandationController.createRecommandation);

// Route pour mettre à jour une recommandation
router.put('/:id', recommandationController.updateRecommandation);

// Route pour supprimer une recommandation
router.delete('/:id', recommandationController.deleteRecommandation);

module.exports = router;
