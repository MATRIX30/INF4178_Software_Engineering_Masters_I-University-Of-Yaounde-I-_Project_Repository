const express = require('express');
const router = express.Router();
const CultureController = require('../controllers/CultureController');

const cultureController = new CultureController();

// GET /cultures
router.get('/cultures', cultureController.getAllCultures.bind(cultureController));

// GET /cultures/:id
router.get('/cultures/:id', cultureController.getCultureById.bind(cultureController));

// POST /cultures
router.post('/cultures', cultureController.createCulture.bind(cultureController));

// PUT /cultures/:id
router.put('/cultures/:id', cultureController.updateCulture.bind(cultureController));

// DELETE /cultures/:id
router.delete('/cultures/:id', cultureController.deleteCulture.bind(cultureController));

module.exports = router;
