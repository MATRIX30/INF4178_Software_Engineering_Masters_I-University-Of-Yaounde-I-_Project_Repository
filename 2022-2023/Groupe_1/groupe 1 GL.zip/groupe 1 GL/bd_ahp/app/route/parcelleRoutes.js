const express = require('express');
const router = express.Router();
const ParcelleController = require('../controllers/ParcelleController');

const parcelleController = new ParcelleController();

// GET /parcelles
router.get('/', parcelleController.getAllParcelles);

// GET /parcelles/:id
router.get('/:id', parcelleController.getParcelleById);

// POST /parcelles
router.post('/', parcelleController.createParcelle);

// PUT /parcelles/:id
router.put('/:id', parcelleController.updateParcelle);

// DELETE /parcelles/:id
router.delete('/:id', parcelleController.deleteParcelle);

module.exports = router;
