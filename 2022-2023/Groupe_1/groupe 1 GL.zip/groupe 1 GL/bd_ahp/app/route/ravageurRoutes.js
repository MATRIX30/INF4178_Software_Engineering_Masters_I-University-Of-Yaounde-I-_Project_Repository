const express = require('express');
const RavageurController = require('../controllers/RavageurController');

const router = express.Router();
const ravageurController = new RavageurController();

// GET /ravageurs
router.get('/', ravageurController.getAllRavageurs);

// GET /ravageurs/:id
router.get('/:id', ravageurController.getRavageurById);

// POST /ravageurs
router.post('/', ravageurController.createRavageur);

// PUT /ravageurs/:id
router.put('/:id', ravageurController.updateRavageur);

// DELETE /ravageurs/:id
router.delete('/:id', ravageurController.deleteRavageur);

module.exports = router;
