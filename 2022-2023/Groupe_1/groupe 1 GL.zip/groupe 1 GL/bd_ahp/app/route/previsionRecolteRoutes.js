const express = require('express');
const router = express.Router();
const PrevisionRecolteController = require('../controllers/PrevisionRecolteController');

const previsionRecolteController = new PrevisionRecolteController();

// GET /previsions-recolte
router.get('/', previsionRecolteController.getAllPrevisionsRecolte);

// GET /previsions-recolte/:id
router.get('/:id', previsionRecolteController.getPrevisionRecolteById);

// POST /previsions-recolte
router.post('/', previsionRecolteController.createPrevisionRecolte);

// PUT /previsions-recolte/:id
router.put('/:id', previsionRecolteController.updatePrevisionRecolte);

// DELETE /previsions-recolte/:id
router.delete('/:id', previsionRecolteController.deletePrevisionRecolte);

module.exports = router;
