const Maladie = require('../models/Maladie');

class MaladieService {
  async getAllMaladies() {
    try {
      const maladies = await Maladie.findAll();
      return maladies;
    } catch (error) {
      throw new Error('Erreur lors de la récupération des maladies');
    }
  }

  async getMaladieById(id) {
    try {
      const maladie = await Maladie.findByPk(id);
      if (!maladie) {
        throw new Error('Maladie non trouvée');
      }
      return maladie;
    } catch (error) {
      throw new Error('Erreur lors de la récupération de la maladie');
    }
  }

  async createMaladie(data) {
    try {
      const maladie = await Maladie.create(data);
      return maladie;
    } catch (error) {
      throw new Error('Erreur lors de la création de la maladie');
    }
  }

  async updateMaladie(id, data) {
    try {
      const maladie = await Maladie.findByPk(id);
      if (!maladie) {
        throw new Error('Maladie non trouvée');
      }
      await maladie.update(data);
      return maladie;
    } catch (error) {
      throw new Error('Erreur lors de la mise à jour de la maladie');
    }
  }

  async deleteMaladie(id) {
    try {
      const maladie = await Maladie.findByPk(id);
      if (!maladie) {
        throw new Error('Maladie non trouvée');
      }
      await maladie.destroy();
    } catch (error) {
      throw new Error('Erreur lors de la suppression de la maladie');
    }
  }
}

module.exports = MaladieService;
