const Ravageur = require('../models/Ravageur');

class RavageurService {
  async getAllRavageurs() {
    try {
      const ravageurs = await Ravageur.findAll();
      return ravageurs;
    } catch (error) {
      throw new Error('Failed to fetch ravageurs from the database.');
    }
  }

  async getRavageurById(id) {
    try {
      const ravageur = await Ravageur.findByPk(id);
      if (!ravageur) {
        throw new Error('Ravageur not found.');
      }
      return ravageur;
    } catch (error) {
      throw new Error('Failed to fetch ravageur from the database.');
    }
  }

  async createRavageur(data) {
    try {
      const ravageur = await Ravageur.create(data);
      return ravageur;
    } catch (error) {
      throw new Error('Failed to create ravageur.');
    }
  }

  async updateRavageur(id, data) {
    try {
      const ravageur = await Ravageur.findByPk(id);
      if (!ravageur) {
        throw new Error('Ravageur not found.');
      }
      await ravageur.update(data);
      return ravageur;
    } catch (error) {
      throw new Error('Failed to update ravageur.');
    }
  }

  async deleteRavageur(id) {
    try {
      const ravageur = await Ravageur.findByPk(id);
      if (!ravageur) {
        throw new Error('Ravageur not found.');
      }
      await ravageur.destroy();
      return ravageur;
    } catch (error) {
      throw new Error('Failed to delete ravageur.');
    }
  }
}

module.exports = RavageurService;
