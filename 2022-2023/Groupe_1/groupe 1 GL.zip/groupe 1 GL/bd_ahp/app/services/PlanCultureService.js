const PlanCulture = require('../models/PlanCulture');

class PlanCultureService {
  async getAllPlans() {
    return PlanCulture.findAll();
  }

  async getPlanById(id) {
    return PlanCulture.findByPk(id);
  }

  async createPlan(planData) {
    return PlanCulture.create(planData);
  }

  async updatePlan(id, planData) {
    const plan = await PlanCulture.findByPk(id);
    if (!plan) {
      throw new Error('Plan not found');
    }
    return plan.update(planData);
  }

  async deletePlan(id) {
    const plan = await PlanCulture.findByPk(id);
    if (!plan) {
      throw new Error('Plan not found');
    }
    return plan.destroy();
  }
}

module.exports = PlanCultureService;
