const CoutProduction = require('../models/CoutProduction');

class CoutProductionService {
  async getAllCoutsProduction() {
    try {
      const coutsProduction = await CoutProduction.findAll();
      return coutsProduction;
    } catch (error) {
      throw new Error('Erreur lors de la récupération des coûts de production');
    }
  }

  async getCoutProductionById(id) {
    try {
      const coutProduction = await CoutProduction.findByPk(id);
      if (!coutProduction) {
        throw new Error('Cout de production non trouvé');
      }
      return coutProduction;
    } catch (error) {
      throw new Error('Erreur lors de la récupération du cout de production');
    }
  }

  async createCoutProduction(data) {
    try {
      const coutProduction = await CoutProduction.create(data);
      return coutProduction;
    } catch (error) {
      throw new Error('Erreur lors de la création du cout de production');
    }
  }

  async updateCoutProduction(id, data) {
    try {
      const coutProduction = await CoutProduction.findByPk(id);
      if (!coutProduction) {
        throw new Error('Cout de production non trouvé');
      }
      await coutProduction.update(data);
      return coutProduction;
    } catch (error) {
      throw new Error('Erreur lors de la mise à jour du cout de production');
    }
  }

  async deleteCoutProduction(id) {
    try {
      const coutProduction = await CoutProduction.findByPk(id);
      if (!coutProduction) {
        throw new Error('Cout de production non trouvé');
      }
      await coutProduction.destroy();
    } catch (error) {
      throw new Error('Erreur lors de la suppression du cout de production');
    }
  }
}

module.exports = CoutProductionService;
