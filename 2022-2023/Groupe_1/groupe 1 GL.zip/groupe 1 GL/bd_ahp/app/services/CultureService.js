const Culture = require('../models/Culture');

class CultureService {
  async getAllCultures() {
    try {
      const cultures = await Culture.findAll();
      return cultures;
    } catch (error) {
      throw new Error('Failed to fetch cultures');
    }
  }

  async getCultureById(id) {
    try {
      const culture = await Culture.findByPk(id);
      if (!culture) {
        throw new Error('Culture not found');
      }
      return culture;
    } catch (error) {
      throw new Error('Failed to fetch culture');
    }
  }

  async createCulture(data) {
    try {
      const culture = await Culture.create(data);
      return culture;
    } catch (error) {
      throw new Error('Failed to create culture');
    }
  }

  async updateCulture(id, data) {
    try {
      const culture = await Culture.findByPk(id);
      if (!culture) {
        throw new Error('Culture not found');
      }
      await culture.update(data);
      return culture;
    } catch (error) {
      throw new Error('Failed to update culture');
    }
  }

  async deleteCulture(id) {
    try {
      const culture = await Culture.findByPk(id);
      if (!culture) {
        throw new Error('Culture not found');
      }
      await culture.destroy();
      return { message: 'Culture deleted successfully' };
    } catch (error) {
      throw new Error('Failed to delete culture');
    }
  }
}

module.exports = CultureService;
