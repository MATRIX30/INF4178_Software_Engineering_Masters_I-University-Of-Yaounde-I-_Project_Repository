const Utilisateur = require('../models/Utilisateur');

class UtilisateurService {
  async createUtilisateur(nom, prenom, email, motDePasse) {
    return await Utilisateur.create({ nom, prenom, email, motDePasse });
  }

  async getAllUtilisateurs() {
    return await Utilisateur.findAll();
  }

  async getUtilisateurById(id) {
    return await Utilisateur.findByPk(id);
  }

  async updateUtilisateur(id, newData) {
    const utilisateur = await Utilisateur.findByPk(id);
    if (utilisateur) {
      return await utilisateur.update(newData);
    }
    return null;
  }

  async deleteUtilisateur(id) {
    const utilisateur = await Utilisateur.findByPk(id);
    if (utilisateur) {
      await utilisateur.destroy();
      return true;
    }
    return false;
  }
}

module.exports = UtilisateurService;
