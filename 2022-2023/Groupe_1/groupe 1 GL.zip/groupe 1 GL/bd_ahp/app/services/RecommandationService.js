const Recommandation = require('../models/Recommandation');

class RecommandationService {
  // Récupérer toutes les recommandations
  async getAllRecommandations() {
    try {
      const recommandations = await Recommandation.findAll();
      return recommandations;
    } catch (error) {
      throw new Error('Impossible de récupérer les recommandations.');
    }
  }

  // Récupérer une recommandation par son identifiant
  async getRecommandationById(id) {
    try {
      const recommandation = await Recommandation.findByPk(id);
      if (!recommandation) {
        throw new Error('Recommandation introuvable.');
      }
      return recommandation;
    } catch (error) {
      throw new Error('Impossible de récupérer la recommandation.');
    }
  }

  // Créer une nouvelle recommandation
  async createRecommandation(data) {
    try {
      const recommandation = await Recommandation.create(data);
      return recommandation;
    } catch (error) {
      throw new Error('Impossible de créer la recommandation.');
    }
  }

  // Mettre à jour une recommandation
  async updateRecommandation(id, data) {
    try {
      const recommandation = await Recommandation.findByPk(id);
      if (!recommandation) {
        throw new Error('Recommandation introuvable.');
      }
      const updatedRecommandation = await recommandation.update(data);
      return updatedRecommandation;
    } catch (error) {
      throw new Error('Impossible de mettre à jour la recommandation.');
    }
  }

  // Supprimer une recommandation
  async deleteRecommandation(id) {
    try {
      const recommandation = await Recommandation.findByPk(id);
      if (!recommandation) {
        throw new Error('Recommandation introuvable.');
      }
      await recommandation.destroy();
    } catch (error) {
      throw new Error('Impossible de supprimer la recommandation.');
    }
  }
}

module.exports = RecommandationService;
