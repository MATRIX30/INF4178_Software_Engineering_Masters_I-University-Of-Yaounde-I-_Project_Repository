import Agenda from '../models/Agenda.cjs';

class AgendaService {
  async getAllAgendas() {
    try {
      const agendas = await Agenda.findAll();
      return agendas;
    } catch (error) {
      throw new Error('Unable to fetch agendas from the database.');
    }
  }

  async getAgendaById(id) {
    try {
      const agenda = await Agenda.findByPk(id);
      if (!agenda) {
        throw new Error('Agenda not found.');
      }
      return agenda;
    } catch (error) {
      throw new Error('Unable to fetch the agenda from the database.');
    }
  }

  async createAgenda(data) {
    try {
      const agenda = await Agenda.create(data);
      return agenda;
    } catch (error) {
      throw new Error('Unable to create the agenda.');
    }
  }

  async updateAgenda(id, data) {
    try {
      const agenda = await Agenda.findByPk(id);
      if (!agenda) {
        throw new Error('Agenda not found.');
      }
      await agenda.update(data);
      return agenda;
    } catch (error) {
      throw new Error('Unable to update the agenda.');
    }
  }

  async deleteAgenda(id) {
    try {
      const agenda = await Agenda.findByPk(id);
      if (!agenda) {
        throw new Error('Agenda not found.');
      }
      await agenda.destroy();
    } catch (error) {
      throw new Error('Unable to delete the agenda.');
    }
  }
}

export default AgendaService;
