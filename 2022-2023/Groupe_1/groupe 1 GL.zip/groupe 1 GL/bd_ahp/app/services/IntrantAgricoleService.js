const IntrantAgricole = require('../models/IntrantAgricole');

class IntrantAgricoleService {
  async getAllIntrantsAgricoles() {
    try {
      const intrants = await IntrantAgricole.findAll();
      return intrants;
    } catch (error) {
      throw new Error('Erreur lors de la récupération des intrants agricoles.');
    }
  }

  async getIntrantAgricoleById(id) {
    try {
      const intrant = await IntrantAgricole.findByPk(id);
      return intrant;
    } catch (error) {
      throw new Error('Erreur lors de la récupération de l\'intrant agricole.');
    }
  }

  async createIntrantAgricole(data) {
    try {
      const intrant = await IntrantAgricole.create(data);
      return intrant;
    } catch (error) {
      throw new Error('Erreur lors de la création de l\'intrant agricole.');
    }
  }

  async updateIntrantAgricole(id, data) {
    try {
      const intrant = await IntrantAgricole.findByPk(id);
      if (intrant) {
        await intrant.update(data);
        return intrant;
      }
      return null;
    } catch (error) {
      throw new Error('Erreur lors de la mise à jour de l\'intrant agricole.');
    }
  }

  async deleteIntrantAgricole(id) {
    try {
      const intrant = await IntrantAgricole.findByPk(id);
      if (intrant) {
        await intrant.destroy();
        return true;
      }
      return false;
    } catch (error) {
      throw new Error('Erreur lors de la suppression de l\'intrant agricole.');
    }
  }
}

module.exports = IntrantAgricoleService;
