const Tache = require('../models/Tache');

class TacheService {
  async getAllTaches() {
    try {
      const taches = await Tache.findAll();
      return taches;
    } catch (error) {
      throw new Error('Failed to retrieve taches');
    }
  }

  async getTacheById(id) {
    try {
      const tache = await Tache.findByPk(id);
      if (!tache) {
        throw new Error('Tache not found');
      }
      return tache;
    } catch (error) {
      throw new Error('Failed to retrieve tache');
    }
  }

  async createTache(data) {
    try {
      const tache = await Tache.create(data);
      return tache;
    } catch (error) {
      throw new Error('Failed to create tache');
    }
  }

  async updateTache(id, data) {
    try {
      const tache = await Tache.findByPk(id);
      if (!tache) {
        throw new Error('Tache not found');
      }
      await tache.update(data);
      return tache;
    } catch (error) {
      throw new Error('Failed to update tache');
    }
  }

  async deleteTache(id) {
    try {
      const tache = await Tache.findByPk(id);
      if (!tache) {
        throw new Error('Tache not found');
      }
      await tache.destroy();
      return { message: 'Tache deleted successfully' };
    } catch (error) {
      throw new Error('Failed to delete tache');
    }
  }
}

module.exports = TacheService;
