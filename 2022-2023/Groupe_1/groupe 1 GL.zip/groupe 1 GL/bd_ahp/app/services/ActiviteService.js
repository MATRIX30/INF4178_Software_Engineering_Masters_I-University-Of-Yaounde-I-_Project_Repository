import Activite from '../models/Activite.cjs';

class ActiviteService {
  // Récupérer toutes les activités
  async getAllActivites() {
    try {
      const activites = await Activite.findAll();
      return activites;
    } catch (error) {
      throw new Error('Erreur lors de la récupération des activités.');
    }
  }

  // Récupérer une activité par son ID
  async getActiviteById(id) {
    try {
      const activite = await Activite.findByPk(id);
      if (!activite) {
        throw new Error('Activité non trouvée.');
      }
      return activite;
    } catch (error) {
      throw new Error('Erreur lors de la récupération de l\'activité.');
    }
  }

  // Créer une nouvelle activité
  async createActivite(nom, description) {
    try {
      const activite = await Activite.create({
        nom_activite: nom,
        description: description,
      });
      return activite;
    } catch (error) {
      throw new Error('Erreur lors de la création de l\'activité.');
    }
  }

  // Mettre à jour une activité
  async updateActivite(id, nom, description) {
    try {
      const activite = await Activite.findByPk(id);
      if (!activite) {
        throw new Error('Activité non trouvée.');
      }
      activite.nom_activite = nom;
      activite.description = description;
      await activite.save();
      return activite;
    } catch (error) {
      throw new Error('Erreur lors de la mise à jour de l\'activité.');
    }
  }

  // Supprimer une activité
  async deleteActivite(id) {
    try {
      const activite = await Activite.findByPk(id);
      if (!activite) {
        throw new Error('Activité non trouvée.');
      }
      await activite.destroy();
      return activite;
    } catch (error) {
      throw new Error('Erreur lors de la suppression de l\'activité.');
    }
  }
}

export default ActiviteService;
