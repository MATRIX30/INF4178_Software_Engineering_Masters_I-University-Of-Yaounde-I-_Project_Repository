const PrevisionRecolte = require('../models/PrevisionRecolte');

class PrevisionRecolteService {
  async getAllPrevisionsRecolte() {
    try {
      const previsions = await PrevisionRecolte.findAll();
      return previsions;
    } catch (error) {
      throw new Error('Erreur lors de la récupération des prévisions de récolte');
    }
  }

  async getPrevisionRecolteById(id) {
    try {
      const prevision = await PrevisionRecolte.findByPk(id);
      if (!prevision) {
        throw new Error('Prévision de récolte introuvable');
      }
      return prevision;
    } catch (error) {
      throw new Error('Erreur lors de la récupération de la prévision de récolte');
    }
  }

  async createPrevisionRecolte(previsionData) {
    try {
      const prevision = await PrevisionRecolte.create(previsionData);
      return prevision;
    } catch (error) {
      throw new Error('Erreur lors de la création de la prévision de récolte');
    }
  }

  async updatePrevisionRecolte(id, previsionData) {
    try {
      const prevision = await PrevisionRecolte.findByPk(id);
      if (!prevision) {
        throw new Error('Prévision de récolte introuvable');
      }
      await prevision.update(previsionData);
      return prevision;
    } catch (error) {
      throw new Error('Erreur lors de la mise à jour de la prévision de récolte');
    }
  }

  async deletePrevisionRecolte(id) {
    try {
      const prevision = await PrevisionRecolte.findByPk(id);
      if (!prevision) {
        throw new Error('Prévision de récolte introuvable');
      }
      await prevision.destroy();
      return prevision;
    } catch (error) {
      throw new Error('Erreur lors de la suppression de la prévision de récolte');
    }
  }
}

module.exports = PrevisionRecolteService;
