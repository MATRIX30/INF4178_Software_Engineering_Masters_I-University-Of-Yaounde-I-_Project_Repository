const MainDOeuvre = require('../models/MainDOeuvre');

class MainDOeuvreService {
  static async getAllMainDOeuvres() {
    try {
      const mainDOeuvres = await MainDOeuvre.findAll();
      return mainDOeuvres;
    } catch (error) {
      throw new Error('Failed to fetch MainDOeuvres');
    }
  }

  static async getMainDOeuvreById(id) {
    try {
      const mainDOeuvre = await MainDOeuvre.findByPk(id);
      if (!mainDOeuvre) {
        throw new Error('MainDOeuvre not found');
      }
      return mainDOeuvre;
    } catch (error) {
      throw new Error('Failed to fetch MainDOeuvre');
    }
  }

  static async createMainDOeuvre(data) {
    try {
      const mainDOeuvre = await MainDOeuvre.create(data);
      return mainDOeuvre;
    } catch (error) {
      throw new Error('Failed to create MainDOeuvre');
    }
  }

  static async updateMainDOeuvre(id, data) {
    try {
      const mainDOeuvre = await MainDOeuvre.findByPk(id);
      if (!mainDOeuvre) {
        throw new Error('MainDOeuvre not found');
      }
      await mainDOeuvre.update(data);
      return mainDOeuvre;
    } catch (error) {
      throw new Error('Failed to update MainDOeuvre');
    }
  }

  static async deleteMainDOeuvre(id) {
    try {
      const mainDOeuvre = await MainDOeuvre.findByPk(id);
      if (!mainDOeuvre) {
        throw new Error('MainDOeuvre not found');
      }
      await mainDOeuvre.destroy();
    } catch (error) {
      throw new Error('Failed to delete MainDOeuvre');
    }
  }
}

module.exports = MainDOeuvreService;
