const RendementCulture = require('../models/RendementCulture');

class RendementCultureService {
  async getAllRendementsCultures() {
    try {
      const rendementsCultures = await RendementCulture.findAll();
      return rendementsCultures;
    } catch (error) {
      throw new Error('Erreur lors de la récupération des rendements des cultures.');
    }
  }

  async getRendementCultureById(id) {
    try {
      const rendementCulture = await RendementCulture.findByPk(id);
      if (!rendementCulture) {
        throw new Error('Rendement de culture non trouvé.');
      }
      return rendementCulture;
    } catch (error) {
      throw new Error('Erreur lors de la récupération du rendement de culture.');
    }
  }

  async createRendementCulture(rendementCultureData) {
    try {
      const rendementCulture = await RendementCulture.create(rendementCultureData);
      return rendementCulture;
    } catch (error) {
      throw new Error('Erreur lors de la création du rendement de culture.');
    }
  }

  async updateRendementCulture(id, rendementCultureData) {
    try {
      const rendementCulture = await RendementCulture.findByPk(id);
      if (!rendementCulture) {
        throw new Error('Rendement de culture non trouvé.');
      }
      await rendementCulture.update(rendementCultureData);
      return rendementCulture;
    } catch (error) {
      throw new Error('Erreur lors de la mise à jour du rendement de culture.');
    }
  }

  async deleteRendementCulture(id) {
    try {
      const rendementCulture = await RendementCulture.findByPk(id);
      if (!rendementCulture) {
        throw new Error('Rendement de culture non trouvé.');
      }
      await rendementCulture.destroy();
    } catch (error) {
      throw new Error('Erreur lors de la suppression du rendement de culture.');
    }
  }
}

module.exports = RendementCultureService;
