const Parcelle = require('../models/Parcelle');

class ParcelleService {
  async getAllParcelles() {
    try {
      const parcelles = await Parcelle.findAll();
      return parcelles;
    } catch (error) {
      throw new Error('Failed to retrieve parcelles from the database.');
    }
  }

  async getParcelleById(id) {
    try {
      const parcelle = await Parcelle.findByPk(id);
      if (!parcelle) {
        throw new Error('Parcelle not found.');
      }
      return parcelle;
    } catch (error) {
      throw new Error('Failed to retrieve parcelle from the database.');
    }
  }

  async createParcelle(parcelleData) {
    try {
      const parcelle = await Parcelle.create(parcelleData);
      return parcelle;
    } catch (error) {
      throw new Error('Failed to create parcelle.');
    }
  }

  async updateParcelle(id, parcelleData) {
    try {
      const parcelle = await Parcelle.findByPk(id);
      if (!parcelle) {
        throw new Error('Parcelle not found.');
      }
      await parcelle.update(parcelleData);
      return parcelle;
    } catch (error) {
      throw new Error('Failed to update parcelle.');
    }
  }

  async deleteParcelle(id) {
    try {
      const parcelle = await Parcelle.findByPk(id);
      if (!parcelle) {
        throw new Error('Parcelle not found.');
      }
      await parcelle.destroy();
      return true;
    } catch (error) {
      throw new Error('Failed to delete parcelle.');
    }
  }
}

module.exports = ParcelleService;
