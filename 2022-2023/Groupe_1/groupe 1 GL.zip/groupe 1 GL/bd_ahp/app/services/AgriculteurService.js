import Agriculteur from '../models/Agriculteur.cjs';


class AgriculteurService {
  // Récupérer tous les agriculteurs
  async getAllAgriculteurs() {
    try {
      const agriculteurs = await Agriculteur.findAll();
      return agriculteurs;
    } catch (error) {
      throw new Error('Impossible de récupérer les agriculteurs');
    }
  }

  // Récupérer un agriculteur par son identifiant
  async getAgriculteurById(id) {
    try {
      const agriculteur = await Agriculteur.findByPk(id);
      if (!agriculteur) {
        throw new Error('Agriculteur non trouvé');
      }
      return agriculteur;
    } catch (error) {
      throw new Error('Impossible de récupérer l\'agriculteur');
    }
  }

  // Créer un nouvel agriculteur
  async createAgriculteur(agriculteurData) {
    try {
      const agriculteur = await Agriculteur.create(agriculteurData);
      return agriculteur;
    } catch (error) {
      throw new Error('Impossible de créer l\'agriculteur');
    }
  }

  // Mettre à jour un agriculteur existant
  async updateAgriculteur(id, agriculteurData) {
    try {
      const agriculteur = await Agriculteur.findByPk(id);
      if (!agriculteur) {
        throw new Error('Agriculteur non trouvé');
      }
      await agriculteur.update(agriculteurData);
      return agriculteur;
    } catch (error) {
      throw new Error('Impossible de mettre à jour l\'agriculteur');
    }
  }

  // Supprimer un agriculteur par son identifiant
  async deleteAgriculteur(id) {
    try {
      const agriculteur = await Agriculteur.findByPk(id);
      if (!agriculteur) {
        throw new Error('Agriculteur non trouvé');
      }
      await agriculteur.destroy();
      return agriculteur;
    } catch (error) {
      throw new Error('Impossible de supprimer l\'agriculteur');
    }
  }
}

export default AgriculteurService;
