const { Sequelize, sequelize } = require('../config/sequelize');

const Equipement_agricole = sequelize.define('Equipement_agricole', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  nom_equipement: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  utilisation: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  description: {
    type: Sequelize.TEXT,
  },
});

module.exports = Equipement_agricole;
