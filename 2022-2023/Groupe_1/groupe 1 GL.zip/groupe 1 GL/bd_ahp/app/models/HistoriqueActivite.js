const { Sequelize, sequelize } = require('../config/sequelize');
const Agriculteur = require('./Agriculteur');

const HistoriqueActivite = sequelize.define('HistoriqueActivite', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    id_agriculteur: {
      type: Sequelize.INTEGER,
      references: {
        model: 'Agriculteur',
        key: 'id',
      },
      allowNull: false,
    },
    action: {
      type: Sequelize.STRING,
    },
    date_heure: {
      type: Sequelize.DATE,
      defaultValue: Sequelize.NOW,
    },
    detail: {
      type: Sequelize.STRING,
    },
  });
  
  HistoriqueActivite.belongsTo(Agriculteur, { foreignKey: 'id_agriculteur' });
  module.exports = HistoriqueActivite;
  