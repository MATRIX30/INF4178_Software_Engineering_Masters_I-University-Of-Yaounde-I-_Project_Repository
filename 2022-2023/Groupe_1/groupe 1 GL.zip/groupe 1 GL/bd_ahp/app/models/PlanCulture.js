import { Sequelize, sequelize } from '../../config/sequelize.js';

const Culture = require('./Culture');

const PlanCulture = sequelize.define('PlanCulture', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  date_debut_culture: {
    type: Sequelize.DATE,
  },
  date_fin_culture: {
    type: Sequelize.DATE,
  },
  description: {
    type: Sequelize.STRING,
  },
  quantite_semence: {
    type: Sequelize.FLOAT,
  },
  parcelle_terre_occupe: {
    type: Sequelize.STRING,
  },
  id_culture: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'Culture',
      key: 'id'
    }
  }
});

PlanCulture.belongsTo(Culture, { foreignKey: 'id_culture' });

export default PlanCulture;
