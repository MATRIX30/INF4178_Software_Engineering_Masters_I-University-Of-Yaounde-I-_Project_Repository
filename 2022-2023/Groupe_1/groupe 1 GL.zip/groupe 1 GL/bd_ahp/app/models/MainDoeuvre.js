const { Sequelize, sequelize } = require('../config/sequelize');

const MainDOeuvre = sequelize.define('MainDOeuvre', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    id_culture: {
      type: Sequelize.INTEGER,
      references: {
        model: 'Culture',
        key: 'id',
      },
      allowNull: false,
    },
    nom_responsable: {
      type: Sequelize.STRING,
    },
    tel_responsable: {
      type: Sequelize.STRING,
    },
    sexe_main_oeuvre: {
      type: Sequelize.STRING,
    },
    saison_travail: {
      type: Sequelize.STRING,
    },
    nom_main_oeuvre: {
      type: Sequelize.STRING,
    },
    prenom_main_oeuvre: {
      type: Sequelize.STRING,
    },
    poste_main_oeuvre: {
      type: Sequelize.STRING,
    },
  });
  
  module.exports = MainDOeuvre;
  