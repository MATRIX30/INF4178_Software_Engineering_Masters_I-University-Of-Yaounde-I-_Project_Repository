// import { Sequelize } from 'sequelize';
import { Sequelize, sequelize } from '../../config/sequelize.js';

// const  = default;

const Agriculteur = sequelize.define('Agriculteur', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  lieu_residence: {
    type: Sequelize.STRING,
    allowNull: false
  },
  experience: {
    type: Sequelize.ENUM('debutant', 'intermediaire', 'expert'),
    allowNull: false,
  },
  photo_utilisateur: {
    type: Sequelize.STRING,
  },
  id_utilisateur: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'Utilisateur',
      key: 'id',
    },
  },
  id_type_exploitation: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'TypeExploitation',
      key: 'id',
    },
  },
  age: {
    type: Sequelize.INTEGER,
  },
  telephone_1: {
    type:Sequelize.STRING,
  },
  telephone_2: {
    type: Sequelize.STRING,
  },
  formation: {
    type: Sequelize.STRING,
  },
  Localisation: {
    type: Sequelize.STRING,
  },
  methode_culture: {
    type: Sequelize.STRING,
  },
  id_equipement_agricole: {
    type: Sequelize.INTEGER,
  },
  id_main_oeuvre: {
    type: Sequelize.INTEGER,
  },
  sexe_agriculteur: {
    type: Sequelize.STRING,
  },
});

export default Agriculteur;
