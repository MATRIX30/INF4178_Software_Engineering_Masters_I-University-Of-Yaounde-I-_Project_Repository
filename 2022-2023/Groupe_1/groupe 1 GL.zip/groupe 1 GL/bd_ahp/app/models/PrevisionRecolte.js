const { Sequelize, sequelize } = require('../config/sequelize');
const Culture = require('./Culture');


const PrevisionRecolte = sequelize.define('PrevisionRecolte', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_culture: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'Culture',
      key: 'id'
    }
  },
  parcelle_terre_occupe: {
    type: Sequelize.STRING,
    allowNull: false
  },
  date_recolte_estimee: {
    type: Sequelize.DATE,
    allowNull: false
  },
  volume_recolte_prevu: {
    type: Sequelize.FLOAT,
    allowNull: false
  }
});

PrevisionRecolte.belongsTo(Culture, { foreignKey: 'id_culture' });

module.exports = PrevisionRecolte;
