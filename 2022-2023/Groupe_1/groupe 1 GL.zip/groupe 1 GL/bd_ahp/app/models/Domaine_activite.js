// Importez Sequelize et la classe Model
const { Sequelize, sequelize } = require('../config/sequelize');

const Domaine_activite = sequelize.define('Domaine_activite', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nom: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    description: {
      type: Sequelize.TEXT,
    },
  });
  
  module.exports = Domaine_activite;
  
