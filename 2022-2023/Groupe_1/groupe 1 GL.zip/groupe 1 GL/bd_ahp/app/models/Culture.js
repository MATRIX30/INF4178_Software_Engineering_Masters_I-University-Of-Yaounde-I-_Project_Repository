const { Sequelize, sequelize } = require('../config/sequelize');

const Culture = sequelize.define('Culture', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nom_culture: {
      type: Sequelize.STRING,
    },
    variete_culture: {
      type: Sequelize.STRING,
    },
    description: {
      type: Sequelize.STRING,
    },
    date_plantation: {
      type: Sequelize.DATE,
    },
    type_culture: {
      type: Sequelize.STRING,
    },
    condition_croissance_culture: {
      type: Sequelize.STRING,
    },
    besoins_arrosage: {
      type: Sequelize.STRING,
    },
    methode_culture: {
      type: Sequelize.STRING,
    },
  });
  
  module.exports = Culture;
  