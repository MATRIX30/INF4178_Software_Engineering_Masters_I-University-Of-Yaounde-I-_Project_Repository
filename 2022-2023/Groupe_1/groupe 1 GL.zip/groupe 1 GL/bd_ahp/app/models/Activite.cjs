import { Sequelize, sequelize } from '../../config/sequelize.js';
const Activite = sequelize.define('Activite', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nom_activite: {
      type: Sequelize.STRING,
    },
    description: {
      type: Sequelize.STRING,
    },
  });
  
  export default Activite;
  