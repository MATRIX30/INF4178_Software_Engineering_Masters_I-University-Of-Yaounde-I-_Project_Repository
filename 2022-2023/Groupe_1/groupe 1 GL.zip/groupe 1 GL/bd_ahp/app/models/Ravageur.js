const { Sequelize, sequelize } = require('../config/sequelize');

const Ravageur = sequelize.define('Ravageur', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  nom_ravageur: {
    type: Sequelize.STRING,
  },
  description: {
    type: Sequelize.TEXT,
  },
  image_ravageur: {
    type: Sequelize.STRING,
  },
  danger_ravageur: {
    type: Sequelize.INTEGER,
  },
});

module.exports = Ravageur;
