const { Sequelize, sequelize } = require('../config/sequelize');

const Tache = sequelize.define('Tache', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nom_tache: {
      type: Sequelize.STRING,
    },
    duree_tache: {
      type: Sequelize.INTEGER,
    },
    repetition: {
      type: Sequelize.BOOLEAN,
    },
    jour_repetition: {
      type: Sequelize.STRING,
    },
    heure_repetition: {
      type: Sequelize.STRING,
    },
    description_tache: {
      type: Sequelize.STRING,
    },
    date_tache: {
      type: Sequelize.DATE,
    },
    date_debut: {
      type: Sequelize.DATE,
    },
    date_fin: {
      type: Sequelize.DATE,
    },
    statut_tache: {
      type: Sequelize.STRING,
    },
  });
  
  module.exports = Tache;
  