const { Sequelize, sequelize } = require('../config/sequelize');


const Utilisateurs = sequelize.define('Utilisateurs', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  mot_passe: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  adresse_email: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true,
    },
  },
  pseudo_utilisateur: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true,
  },
  token_reinitial_mot_passe: {
    type: Sequelize.STRING,
  },
  confirmation_mot_passe: {
    type: Sequelize.BOOLEAN,
    defaultValue: false,
  },
  nom_utilisateur: {
    type: Sequelize.STRING,
  },
  prenom_utilisateur: {
    type: Sequelize.STRING,
  },
});

module.exports = Utilisateurs;
