const { Sequelize, sequelize } = require('../config/sequelize');
const MainDOeuvre = require('./MainDOeuvre');


const Parcelle = sequelize.define('Parcelle', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nom_parcelle: {
    type: Sequelize.STRING,
    allowNull: false
  },
  longeur: {
    type: Sequelize.FLOAT,
    allowNull: false
  },
  largeur: {
    type: Sequelize.FLOAT,
    allowNull: false
  },
  qualite_parcelle: {
    type: Sequelize.STRING,
    allowNull: false
  },
  description: {
    type: Sequelize.STRING,
    allowNull: true
  },
  disponibilite_parcelle: {
    type: Sequelize.BOOLEAN,
    allowNull: false,
    defaultValue: true
  },
  emplacement_geographique: {
    type: Sequelize.STRING,
    allowNull: false
  },
  id_main_oeuvre: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'MainDOeuvre',
      key: 'id'
    }
  }
});

Parcelle.belongsTo(MainDOeuvre, { foreignKey: 'id_main_oeuvre' });

module.exports = Parcelle;
