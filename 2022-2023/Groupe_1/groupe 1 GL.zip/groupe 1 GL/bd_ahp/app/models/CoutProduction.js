const { Sequelize, sequelize } = require('../config/sequelize');
const Culture = require('./Culture');

const CoutProduction = sequelize.define('CoutProduction', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  description: {
    type: Sequelize.STRING,
    allowNull: true
  },
  type_cout: {
    type: Sequelize.STRING,
    allowNull: false
  },
  Montant: {
    type: Sequelize.FLOAT,
    allowNull: false
  },
  id_culture: {
    type: Sequelize.INTEGER,
    references: {
      model: 'Culture',
      key: 'id',
    },
    allowNull: false,
  },
});

CoutProduction.belongsTo(Culture, { foreignKey: 'id_culture' });

module.exports = CoutProduction;
