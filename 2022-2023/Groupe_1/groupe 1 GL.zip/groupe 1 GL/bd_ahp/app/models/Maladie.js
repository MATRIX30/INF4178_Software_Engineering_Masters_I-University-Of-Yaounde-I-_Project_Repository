const { Sequelize, sequelize } = require('../config/sequelize');

const Maladie = sequelize.define('Maladie', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  nom_maladie: {
    type: Sequelize.STRING,
  },
  description: {
    type: Sequelize.TEXT,
  },
  image_maladie: {
    type: Sequelize.STRING,
  },
  danger_maladie: {
    type: Sequelize.INTEGER,
  },
  symptome_maladie: {
    type: Sequelize.TEXT,
  },
});

module.exports = Maladie;
