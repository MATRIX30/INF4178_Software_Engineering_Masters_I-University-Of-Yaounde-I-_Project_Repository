import { Sequelize, sequelize } from '../../config/sequelize.js';

import PlanCulture from './PlanCulture.js';

const Agenda = sequelize.define('Agenda', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  nom: {
    type: Sequelize.STRING,
  },
  description: {
    type: Sequelize.STRING,
  },
  id_plan_culture: {
    type: Sequelize.INTEGER,
    references: {
      model: 'PlanCulture',
      key: 'id',
    },
    allowNull: false,
  },
});

Agenda.belongsTo(PlanCulture, { foreignKey: 'id_plan_culture' });

export default Agenda;
