const { Sequelize, sequelize } = require('../config/sequelize');


const IntrantAgricole = sequelize.define('IntrantAgricole', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nom_intrant: {
    type: Sequelize.STRING,
    allowNull: false
  },
  categorie_intrant: {
    type: Sequelize.STRING,
    allowNull: false
  },
  description: {
    type: Sequelize.TEXT,
    allowNull: true
  },
  quantite_agricole: {
    type: Sequelize.FLOAT,
    allowNull: false
  }
});

module.exports = IntrantAgricole;
