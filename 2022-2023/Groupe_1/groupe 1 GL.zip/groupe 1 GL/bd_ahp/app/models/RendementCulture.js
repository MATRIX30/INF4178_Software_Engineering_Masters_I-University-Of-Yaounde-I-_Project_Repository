const { Sequelize, sequelize } = require('../config/sequelize');
const Culture = require('./Culture');
const Parcelle = require('./Parcelle');

const RendementCulture = sequelize.define('RendementCulture', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  description: {
    type: Sequelize.STRING,
    allowNull: true
  },
  date_rendement_culture: {
    type: Sequelize.DATE,
    allowNull: false
  },
  quantite_rendement_obtenu: {
    type: Sequelize.FLOAT,
    allowNull: false
  },
  id_culture: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'Culture',
      key: 'id',
    },
  },
  id_parcelle_occupee: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'Parcelle',
      key: 'id',
    },
  },
});

RendementCulture.belongsTo(Culture, { foreignKey: 'id_culture' });
RendementCulture.belongsTo(Parcelle, { foreignKey: 'id_parcelle_occupee' });

module.exports = RendementCulture;
