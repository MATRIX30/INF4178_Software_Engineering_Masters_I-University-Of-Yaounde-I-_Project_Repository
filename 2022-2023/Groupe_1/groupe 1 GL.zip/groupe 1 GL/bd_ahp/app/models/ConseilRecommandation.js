const { Sequelize, sequelize } = require('../config/sequelize');

const Ravageur = require('./Ravageur');
const Maladie = require('./Maladie');
const Culture = require('./Culture');

const ConseilRecommandation = sequelize.define('ConseilRecommandation', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  nom_conseil: {
    type: Sequelize.STRING,
  },
  contenu_conseil: {
    type: Sequelize.TEXT,
  },
  id_ravageur: {
    type: Sequelize.INTEGER,
    references: {
      model: 'Ravageur',
      key: 'id',
    },
    allowNull: false,
  },
  id_Maladie: {
    type: Sequelize.INTEGER,
    references: {
      model: 'Maladie',
      key: 'id',
    },
    allowNull: false,
  },
  id_Culture: {
    type: Sequelize.INTEGER,
    references: {
      model: 'Culture',
      key: 'id',
    },
    allowNull: false,
  },
});

// Define associations
ConseilRecommandation.belongsTo(Ravageur, { foreignKey: 'id_ravageur' });
ConseilRecommandation.belongsTo(Maladie, { foreignKey: 'id_maladie' });
ConseilRecommandation.belongsTo(Culture, { foreignKey: 'id_culture' });

module.exports = ConseilRecommandation;
