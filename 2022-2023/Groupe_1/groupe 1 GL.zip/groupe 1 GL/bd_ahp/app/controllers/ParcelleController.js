const ParcelleService = require('../services/ParcelleService');

const parcelleService = new ParcelleService();

class ParcelleController {
  async getAllParcelles(req, res) {
    try {
      const parcelles = await parcelleService.getAllParcelles();
      res.json(parcelles);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getParcelleById(req, res) {
    const { id } = req.params;
    try {
      const parcelle = await parcelleService.getParcelleById(id);
      res.json(parcelle);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async createParcelle(req, res) {
    const parcelleData = req.body;
    try {
      const parcelle = await parcelleService.createParcelle(parcelleData);
      res.status(201).json(parcelle);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async updateParcelle(req, res) {
    const { id } = req.params;
    const parcelleData = req.body;
    try {
      const parcelle = await parcelleService.updateParcelle(id, parcelleData);
      res.json(parcelle);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async deleteParcelle(req, res) {
    const { id } = req.params;
    try {
      await parcelleService.deleteParcelle(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
}

module.exports = ParcelleController;
