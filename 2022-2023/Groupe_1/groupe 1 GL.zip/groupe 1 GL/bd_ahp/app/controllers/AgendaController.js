import AgendaService from '../services/AgendaService.js';
const agendaService = new AgendaService();
class AgendaController {
 
  async getAllAgendas(req, res) {
    try {
      const agendas = await agendaService.getAllAgendas();
      res.json(agendas);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getAgendaById(req, res) {
    const { id } = req.params;
    try {
      const agenda = await agendaService.getAgendaById(id);
      res.json(agenda);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async createAgenda(req, res) {
    const data = req.body;
    try {
      const agenda = await agendaService.createAgenda(data);
      res.json(agenda);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateAgenda(req, res) {
    const { id } = req.params;
    const data = req.body;
    try {
      const agenda = await agendaService.updateAgenda(id, data);
      res.json(agenda);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async deleteAgenda(req, res) {
    const { id } = req.params;
    try {
      await agendaService.deleteAgenda(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

export default AgendaController;
