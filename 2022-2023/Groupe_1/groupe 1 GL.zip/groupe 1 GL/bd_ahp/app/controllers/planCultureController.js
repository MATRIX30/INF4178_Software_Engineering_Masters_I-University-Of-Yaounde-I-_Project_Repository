const PlanCultureService = require('../services/PlanCultureService');

class PlanCultureController {
  constructor() {
    this.planCultureService = new PlanCultureService();
  }

  async getAllPlans(req, res) {
    try {
      const plans = await this.planCultureService.getAllPlans();
      res.json(plans);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getPlanById(req, res) {
    const { id } = req.params;
    try {
      const plan = await this.planCultureService.getPlanById(id);
      if (plan) {
        res.json(plan);
      } else {
        res.status(404).json({ message: 'Plan not found' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async createPlan(req, res) {
    const planData = req.body;
    try {
      const createdPlan = await this.planCultureService.createPlan(planData);
      res.status(201).json(createdPlan);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async updatePlan(req, res) {
    const { id } = req.params;
    const planData = req.body;
    try {
      const updatedPlan = await this.planCultureService.updatePlan(id, planData);
      if (updatedPlan) {
        res.json(updatedPlan);
      } else {
        res.status(404).json({ message: 'Plan not found' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async deletePlan(req, res) {
    const { id } = req.params;
    try {
      const deletedPlan = await this.planCultureService.deletePlan(id);
      if (deletedPlan) {
        res.json({ message: 'Plan deleted' });
      } else {
        res.status(404).json({ message: 'Plan not found' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = PlanCultureController;
