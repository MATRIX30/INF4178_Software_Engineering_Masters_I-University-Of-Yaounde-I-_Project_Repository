const CultureService = require('../services/CultureService');

class CultureController {
  constructor() {
    this.cultureService = new CultureService();
  }

  async getAllCultures(req, res) {
    try {
      const cultures = await this.cultureService.getAllCultures();
      res.status(200).json(cultures);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getCultureById(req, res) {
    const { id } = req.params;
    try {
      const culture = await this.cultureService.getCultureById(id);
      res.status(200).json(culture);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async createCulture(req, res) {
    const { body } = req;
    try {
      const culture = await this.cultureService.createCulture(body);
      res.status(201).json(culture);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateCulture(req, res) {
    const { id } = req.params;
    const { body } = req;
    try {
      const culture = await this.cultureService.updateCulture(id, body);
      res.status(200).json(culture);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async deleteCulture(req, res) {
    const { id } = req.params;
    try {
      await this.cultureService.deleteCulture(id);
      res.status(200).json({ message: 'Culture deleted successfully' });
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }
}

module.exports = CultureController;
