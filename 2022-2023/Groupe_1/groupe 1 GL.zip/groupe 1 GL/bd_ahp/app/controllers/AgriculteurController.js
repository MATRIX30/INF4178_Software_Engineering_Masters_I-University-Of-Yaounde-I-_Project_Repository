import AgriculteurService from '../services/AgriculteurService.js';

class AgriculteurController {
  constructor() {
    this.agriculteurService = new AgriculteurService();
  }

  // Récupérer tous les agriculteurs
  async getAllAgriculteurs(req, res) {
    try {
      const agriculteurs = await this.agriculteurService.getAllAgriculteurs();
      res.status(200).json(agriculteurs);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // Récupérer un agriculteur par son identifiant
  async getAgriculteurById(req, res) {
    const { id } = req.params;
    try {
      const agriculteur = await this.agriculteurService.getAgriculteurById(id);
      res.status(200).json(agriculteur);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // Créer un nouvel agriculteur
  async createAgriculteur(req, res) {
    const agriculteurData = req.body;
    try {
      const agriculteur = await this.agriculteurService.createAgriculteur(agriculteurData);
      res.status(201).json(agriculteur);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // Mettre à jour un agriculteur existant
  async updateAgriculteur(req, res) {
    const { id } = req.params;
    const agriculteurData = req.body;
    try {
      const agriculteur = await this.agriculteurService.updateAgriculteur(id, agriculteurData);
      res.status(200).json(agriculteur);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // Supprimer un agriculteur par son identifiant
  async deleteAgriculteur(req, res) {
    const { id } = req.params;
    try {
      const agriculteur = await this.agriculteurService.deleteAgriculteur(id);
      res.status(200).json(agriculteur);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

export default AgriculteurController;
