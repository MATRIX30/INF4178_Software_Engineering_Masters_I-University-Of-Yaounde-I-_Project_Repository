const MaladieService = require('../services/MaladieService');

const maladieService = new MaladieService();

class MaladieController {
  async getAllMaladies(req, res) {
    try {
      const maladies = await maladieService.getAllMaladies();
      res.status(200).json(maladies);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getMaladieById(req, res) {
    const { id } = req.params;
    try {
      const maladie = await maladieService.getMaladieById(id);
      res.status(200).json(maladie);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async createMaladie(req, res) {
    const { body } = req;
    try {
      const maladie = await maladieService.createMaladie(body);
      res.status(201).json(maladie);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async updateMaladie(req, res) {
    const { id } = req.params;
    const { body } = req;
    try {
      const maladie = await maladieService.updateMaladie(id, body);
      res.status(200).json(maladie);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async deleteMaladie(req, res) {
    const { id } = req.params;
    try {
      await maladieService.deleteMaladie(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }
}

module.exports = MaladieController;
