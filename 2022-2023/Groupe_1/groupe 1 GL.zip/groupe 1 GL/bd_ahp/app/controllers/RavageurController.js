const RavageurService = require('../services/RavageurService');

const ravageurService = new RavageurService();

class RavageurController {
  async getAllRavageurs(req, res) {
    try {
      const ravageurs = await ravageurService.getAllRavageurs();
      res.json(ravageurs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch ravageurs.' });
    }
  }

  async getRavageurById(req, res) {
    const { id } = req.params;
    try {
      const ravageur = await ravageurService.getRavageurById(id);
      res.json(ravageur);
    } catch (error) {
      res.status(404).json({ error: 'Ravageur not found.' });
    }
  }

  async createRavageur(req, res) {
    const ravageurData = req.body;
    try {
      const ravageur = await ravageurService.createRavageur(ravageurData);
      res.status(201).json(ravageur);
    } catch (error) {
      res.status(400).json({ error: 'Failed to create ravageur.' });
    }
  }

  async updateRavageur(req, res) {
    const { id } = req.params;
    const ravageurData = req.body;
    try {
      const ravageur = await ravageurService.updateRavageur(id, ravageurData);
      res.json(ravageur);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update ravageur.' });
    }
  }

  async deleteRavageur(req, res) {
    const { id } = req.params;
    try {
      const ravageur = await ravageurService.deleteRavageur(id);
      res.json(ravageur);
    } catch (error) {
      res.status(400).json({ error: 'Failed to delete ravageur.' });
    }
  }
}

module.exports = RavageurController;
