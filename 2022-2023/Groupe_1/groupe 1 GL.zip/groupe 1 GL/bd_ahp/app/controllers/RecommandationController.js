const RecommandationService = require('../services/RecommandationService');

const recommandationService = new RecommandationService();

class RecommandationController {
  // Récupérer toutes les recommandations
  async getAllRecommandations(req, res) {
    try {
      const recommandations = await recommandationService.getAllRecommandations();
      res.status(200).json(recommandations);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // Récupérer une recommandation par son identifiant
  async getRecommandationById(req, res) {
    const { id } = req.params;
    try {
      const recommandation = await recommandationService.getRecommandationById(id);
      res.status(200).json(recommandation);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  // Créer une nouvelle recommandation
  async createRecommandation(req, res) {
    const data = req.body;
    try {
      const recommandation = await recommandationService.createRecommandation(data);
      res.status(201).json(recommandation);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  // Mettre à jour une recommandation
  async updateRecommandation(req, res) {
    const { id } = req.params;
    const data = req.body;
    try {
      const updatedRecommandation = await recommandationService.updateRecommandation(id, data);
      res.status(200).json(updatedRecommandation);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  // Supprimer une recommandation
  async deleteRecommandation(req, res) {
    const { id } = req.params;
    try {
      await recommandationService.deleteRecommandation(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
}

module.exports = RecommandationController;
