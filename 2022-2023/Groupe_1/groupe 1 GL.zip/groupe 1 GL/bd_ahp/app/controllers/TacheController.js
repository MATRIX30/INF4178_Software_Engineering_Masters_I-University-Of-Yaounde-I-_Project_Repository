const TacheService = require('../services/TacheService');

class TacheController {
  constructor() {
    this.tacheService = new TacheService();
  }

  async getAllTaches(req, res) {
    try {
      const taches = await this.tacheService.getAllTaches();
      res.json(taches);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getTacheById(req, res) {
    const { id } = req.params;
    try {
      const tache = await this.tacheService.getTacheById(id);
      res.json(tache);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async createTache(req, res) {
    const tacheData = req.body;
    try {
      const tache = await this.tacheService.createTache(tacheData);
      res.status(201).json(tache);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateTache(req, res) {
    const { id } = req.params;
    const tacheData = req.body;
    try {
      const tache = await this.tacheService.updateTache(id, tacheData);
      res.json(tache);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async deleteTache(req, res) {
    const { id } = req.params;
    try {
      await this.tacheService.deleteTache(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }
}

module.exports = TacheController;
