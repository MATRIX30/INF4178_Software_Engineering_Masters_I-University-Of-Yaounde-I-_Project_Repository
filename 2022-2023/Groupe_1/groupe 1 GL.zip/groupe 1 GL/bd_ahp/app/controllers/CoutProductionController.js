const CoutProductionService = require('../services/CoutProductionService');

const coutProductionService = new CoutProductionService();

class CoutProductionController {
  async getAllCoutsProduction(req, res) {
    try {
      const coutsProduction = await coutProductionService.getAllCoutsProduction();
      res.status(200).json(coutsProduction);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getCoutProductionById(req, res) {
    const { id } = req.params;
    try {
      const coutProduction = await coutProductionService.getCoutProductionById(id);
      res.status(200).json(coutProduction);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async createCoutProduction(req, res) {
    const data = req.body;
    try {
      const coutProduction = await coutProductionService.createCoutProduction(data);
      res.status(201).json(coutProduction);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateCoutProduction(req, res) {
    const { id } = req.params;
    const data = req.body;
    try {
      const coutProduction = await coutProductionService.updateCoutProduction(id, data);
      res.status(200).json(coutProduction);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async deleteCoutProduction(req, res) {
    const { id } = req.params;
    try {
      await coutProductionService.deleteCoutProduction(id);
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = CoutProductionController;
