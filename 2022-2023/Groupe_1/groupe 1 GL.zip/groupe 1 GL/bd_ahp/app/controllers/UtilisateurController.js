const UtilisateurService = require('../services/UtilisateurService');

const utilisateurService = new UtilisateurService();

class UtilisateurController {
  async createUtilisateur(req, res) {
    const { nom, prenom, email, motDePasse } = req.body;
    try {
      const utilisateur = await utilisateurService.createUtilisateur(nom, prenom, email, motDePasse);
      res.status(201).json(utilisateur);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create utilisateur' });
    }
  }

  async getAllUtilisateurs(req, res) {
    try {
      const utilisateurs = await utilisateurService.getAllUtilisateurs();
      res.json(utilisateurs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch utilisateurs' });
    }
  }

  async getUtilisateurById(req, res) {
    const { id } = req.params;
    try {
      const utilisateur = await utilisateurService.getUtilisateurById(id);
      if (utilisateur) {
        res.json(utilisateur);
      } else {
        res.status(404).json({ error: 'Utilisateur not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch utilisateur' });
    }
  }

  async updateUtilisateur(req, res) {
    const { id } = req.params;
    const newData = req.body;
    try {
      const updatedUtilisateur = await utilisateurService.updateUtilisateur(id, newData);
      if (updatedUtilisateur) {
        res.json(updatedUtilisateur);
      } else {
        res.status(404).json({ error: 'Utilisateur not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to update utilisateur' });
    }
  }

  async deleteUtilisateur(req, res) {
    const { id } = req.params;
    try {
      const deleted = await utilisateurService.deleteUtilisateur(id);
      if (deleted) {
        res.json({ message: 'Utilisateur deleted successfully' });
      } else {
        res.status(404).json({ error: 'Utilisateur not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete utilisateur' });
    }
  }
}

module.exports = UtilisateurController;
