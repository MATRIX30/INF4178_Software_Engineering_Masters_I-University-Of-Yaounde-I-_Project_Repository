import ActiviteService from '../services/ActiviteService.js';

const activiteService = new ActiviteService();

class ActiviteController {
  // Récupérer toutes les activités
  async getAllActivites(req, res) {
    try {
      const activites = await activiteService.getAllActivites();
      res.json(activites);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // Récupérer une activité par son ID
  async getActiviteById(req, res) {
    const { id } = req.params;
    try {
      const activite = await activiteService.getActiviteById(id);
      res.json(activite);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  // Créer une nouvelle activité
  async createActivite(req, res) {
    const { nom, description } = req.body;
    try {
      const activite = await activiteService.createActivite(nom, description);
      res.status(201).json(activite);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // Mettre à jour une activité
  async updateActivite(req, res) {
    const { id } = req.params;
    const { nom, description } = req.body;
    try {
      const activite = await activiteService.updateActivite(id, nom, description);
      res.json(activite);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  // Supprimer une activité
  async deleteActivite(req, res) {
    const { id } = req.params;
    try {
      const activite = await activiteService.deleteActivite(id);
      res.json(activite);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }
}

export default ActiviteController;
