const RendementCultureService = require('../services/RendementCultureService');

const rendementCultureService = new RendementCultureService();

class RendementCultureController {
  async getAllRendementsCultures(req, res) {
    try {
      const rendementsCultures = await rendementCultureService.getAllRendementsCultures();
      res.json(rendementsCultures);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getRendementCultureById(req, res) {
    const { id } = req.params;
    try {
      const rendementCulture = await rendementCultureService.getRendementCultureById(id);
      res.json(rendementCulture);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async createRendementCulture(req, res) {
    const rendementCultureData = req.body;
    try {
      const rendementCulture = await rendementCultureService.createRendementCulture(rendementCultureData);
      res.json(rendementCulture);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateRendementCulture(req, res) {
    const { id } = req.params;
    const rendementCultureData = req.body;
    try {
      const rendementCulture = await rendementCultureService.updateRendementCulture(id, rendementCultureData);
      res.json(rendementCulture);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async deleteRendementCulture(req, res) {
    const { id } = req.params;
    try {
      await rendementCultureService.deleteRendementCulture(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = RendementCultureController;
