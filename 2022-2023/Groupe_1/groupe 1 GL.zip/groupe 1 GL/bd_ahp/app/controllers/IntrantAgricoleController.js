const IntrantAgricoleService = require('../services/IntrantAgricoleService');

const intrantAgricoleService = new IntrantAgricoleService();

class IntrantAgricoleController {
  async getAllIntrantsAgricoles(req, res) {
    try {
      const intrants = await intrantAgricoleService.getAllIntrantsAgricoles();
      res.json(intrants);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getIntrantAgricoleById(req, res) {
    const { id } = req.params;
    try {
      const intrant = await intrantAgricoleService.getIntrantAgricoleById(id);
      if (intrant) {
        res.json(intrant);
      } else {
        res.status(404).json({ error: 'Intrant agricole non trouvé.' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async createIntrantAgricole(req, res) {
    const data = req.body;
    try {
      const intrant = await intrantAgricoleService.createIntrantAgricole(data);
      res.status(201).json(intrant);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateIntrantAgricole(req, res) {
    const { id } = req.params;
    const data = req.body;
    try {
      const intrant = await intrantAgricoleService.updateIntrantAgricole(id, data);
      if (intrant) {
        res.json(intrant);
      } else {
        res.status(404).json({ error: 'Intrant agricole non trouvé.' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async deleteIntrantAgricole(req, res) {
    const { id } = req.params;
    try {
      const result = await intrantAgricoleService.deleteIntrantAgricole(id);
      if (result) {
        res.json({ message: 'Intrant agricole supprimé avec succès.' });
      } else {
        res.status(404).json({ error: 'Intrant agricole non trouvé.' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = IntrantAgricoleController;
