const MainDOeuvreService = require('./services/MainDOeuvreService');

class MainDOeuvreController {
  static async getAllMainDOeuvres(req, res) {
    try {
      const mainDOeuvres = await MainDOeuvreService.getAllMainDOeuvres();
      res.json(mainDOeuvres);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch MainDOeuvres' });
    }
  }

  static async getMainDOeuvreById(req, res) {
    const { id } = req.params;
    try {
      const mainDOeuvre = await MainDOeuvreService.getMainDOeuvreById(id);
      res.json(mainDOeuvre);
    } catch (error) {
      res.status(404).json({ error: 'MainDOeuvre not found' });
    }
  }

  static async createMainDOeuvre(req, res) {
    const data = req.body;
    try {
      const mainDOeuvre = await MainDOeuvreService.createMainDOeuvre(data);
      res.status(201).json(mainDOeuvre);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create MainDOeuvre' });
    }
  }

  static async updateMainDOeuvre(req, res) {
    const { id } = req.params;
    const data = req.body;
    try {
      const mainDOeuvre = await MainDOeuvreService.updateMainDOeuvre(id, data);
      res.json(mainDOeuvre);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update MainDOeuvre' });
    }
  }

  static async deleteMainDOeuvre(req, res) {
    const { id } = req.params;
    try {
      await MainDOeuvreService.deleteMainDOeuvre(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete MainDOeuvre' });
    }
  }
}

module.exports = MainDOeuvreController;
