const PrevisionRecolteService = require('../services/PrevisionRecolteService');

const previsionRecolteService = new PrevisionRecolteService();

class PrevisionRecolteController {
  async getAllPrevisionsRecolte(req, res) {
    try {
      const previsions = await previsionRecolteService.getAllPrevisionsRecolte();
      res.json(previsions);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getPrevisionRecolteById(req, res) {
    const { id } = req.params;
    try {
      const prevision = await previsionRecolteService.getPrevisionRecolteById(id);
      res.json(prevision);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async createPrevisionRecolte(req, res) {
    const previsionData = req.body;
    try {
      const prevision = await previsionRecolteService.createPrevisionRecolte(previsionData);
      res.status(201).json(prevision);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async updatePrevisionRecolte(req, res) {
    const { id } = req.params;
    const previsionData = req.body;
    try {
      const prevision = await previsionRecolteService.updatePrevisionRecolte(id, previsionData);
      res.json(prevision);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }

  async deletePrevisionRecolte(req, res) {
    const { id } = req.params;
    try {
      const prevision = await previsionRecolteService.deletePrevisionRecolte(id);
      res.json(prevision);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  }
}

module.exports = PrevisionRecolteController;
