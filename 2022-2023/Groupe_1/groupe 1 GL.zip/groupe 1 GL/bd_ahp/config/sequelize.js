import { Sequelize } from 'sequelize';

const sequelize = new Sequelize('smallholder', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
});

export default { Sequelize, sequelize };
