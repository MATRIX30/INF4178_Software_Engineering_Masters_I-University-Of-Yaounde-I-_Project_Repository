import express from 'express';
import pkg from 'body-parser';
const { json } = pkg;

require('dotenv').config();
// Import des routes
import agriculteurRoutes from './app/route/agriculteurRoutes.js';
// import utilisateurRoutes from './app/route/utilisateurRoutes.js';
// import mainDoeuvreRoutes from './app/route/mainDoeuvreRoutes.js';
import activiteRoutes from './app/route/activiteRoutes.js';
// import tacheRoutes from './app/route/tacheRoutes.js';
// import cultureRoutes from './app/route/cultureRoutes.js';
// import planCultureRoutes from './app/route/planCultureRoutes.js';
import agendaRoutes from './app/route/agendaRoutes.js';
// import ravageurRoutes from './app/route/ravageurRoutes.js';
// import maladieRoutes from './app/route/maladieRoutes.js';
// import recommandationRoutes from './app/route/recommandationRoutes.js';
// import previsionRecolteRoutes from './app/route/previsionRecolteRoutes.js';
// import parcelleRoutes from './app/route/parcelleRoutes.js';
// import intrantAgricoleRoutes from './app/route/intrantAgricoleRoutes.js';
// import rendementCultureRoutes from './app/route/rendementCultureRoutes.js';
// import coutProductionRoutes from './app/route/coutProductionRoutes.js';
// import rapportRoutes from './app/route/rapportRoutes.js';
const app = express();
const port = process.env.PORT || 3000;

// Middleware pour parser les requêtes au format JSON
app.use(json());

// Routes
app.use('/agriculteurs', agriculteurRoutes);
app.use('/utilisateurs', utilisateurRoutes);
// app.use('/maindoeuvres', mainDoeuvreRoutes);
app.use('/activites', activiteRoutes);
// app.use('/taches', tacheRoutes);
// app.use('/cultures', cultureRoutes);
// app.use('/plancultures', planCultureRoutes);
app.use('/agenda', agendaRoutes);
// app.use('/ravageurs', ravageurRoutes);
// app.use('/maladies', maladieRoutes);
// app.use('/recommandations', recommandationRoutes);
// app.use('/previsionrecoltes', previsionRecolteRoutes);
// app.use('/parcelles', parcelleRoutes);
// app.use('/intrantsagricoles', intrantAgricoleRoutes);
// app.use('/rendementcultures', rendementCultureRoutes);
// app.use('/coutproductions', coutProductionRoutes);
// app.use('/rapports', rapportRoutes);


// Gestion des erreurs 404 (route non trouvée)
app.use((req, res, next) => {
  res.status(404).json({ message: 'Route not found' });
});

// Gestion des erreurs globales
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Internal server error' });
});

// Démarrer le serveur
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
