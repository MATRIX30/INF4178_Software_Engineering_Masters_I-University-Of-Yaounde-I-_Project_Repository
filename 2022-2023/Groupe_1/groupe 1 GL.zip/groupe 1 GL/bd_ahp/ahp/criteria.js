const math = require('mathjs');

class Criterion {
  constructor(name, description) {
    this.name = name;
    this.description = description;
    this.comparisons = [];
  }

  addComparison(criterion, value) {
    this.comparisons.push({ criterion, value });
  }

  getWeight() {
    const comparisonValues = this.comparisons.map((comparison) => comparison.value);
    const comparisonMatrix = math.matrix(comparisonValues);
    const normalizedMatrix = math.divide(comparisonMatrix, math.sum(comparisonMatrix, 0));

    const matrixSum = math.sum(normalizedMatrix, 1);
    const weightVector = math.divide(matrixSum, math.sum(matrixSum));

    return weightVector.toArray();
  }
}

module.exports = Criterion;
