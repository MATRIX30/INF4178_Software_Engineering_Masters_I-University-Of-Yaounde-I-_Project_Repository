const math = require('mathjs');
const Matrix = require('./matrix');
const criteria = require('./criteria');
class AHP {
  constructor(criteria, comparisons) {
    this.criteria = criteria;
    this.comparisons = comparisons;
    this.weights = null;
  }

  calculateWeights() {
    const n = this.criteria.length;
    const comparisonMatrix = new Matrix(n, n);

    // Remplir la matrice de comparaison
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        const comparison = this.comparisons[i][j];
        comparisonMatrix.setValue(i, j, comparison);
      }
    }

    // Normaliser la matrice de comparaison
    const normalizedMatrix = this.normalizeMatrix(comparisonMatrix);

    // Calculer les poids
    const weights = this.calculateEigenvector(normalizedMatrix);

    // Stocker les poids calculés
    this.weights = weights;

    return weights;
  }

  normalizeMatrix(matrix) {
    const n = matrix.getRows();
    const normalizedMatrix = new Matrix(n, n);

    // Calculer les sommes des colonnes
    const columnSums = this.calculateColumnSums(matrix);

    // Normaliser la matrice en divisant chaque élément par la somme de sa colonne
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        const value = matrix.getValue(i, j);
        const normalizedValue = value / columnSums[j];
        normalizedMatrix.setValue(i, j, normalizedValue);
      }
    }

    return normalizedMatrix;
  }

  calculateColumnSums(matrix) {
    const n = matrix.getRows();
    const columnSums = [];

    for (let j = 0; j < n; j++) {
      let sum = 0;

      for (let i = 0; i < n; i++) {
        const value = matrix.getValue(i, j);
        sum += value;
      }

      columnSums.push(sum);
    }

    return columnSums;
  }

  calculateEigenvector(matrix) {
    const n = matrix.getRows();
    const eigenvectorMatrix = new Matrix(n, 1, 1 / n);

    for (let k = 0; k < 10; k++) {
      const previousEigenvector = eigenvectorMatrix;
      const product = matrix.multiply(previousEigenvector);
      const eigenvector = this.normalizeEigenvector(product);
      eigenvectorMatrix.matrix = eigenvector.matrix;

      if (this.hasConverged(previousEigenvector, eigenvector)) {
        break;
      }
    }

    return eigenvectorMatrix.matrix;
  }

  normalizeEigenvector(matrix) {
    const sum = math.sum(matrix);
    const normalizedMatrix = matrix.map((value) => value / sum);
    const resultMatrix = new Matrix(matrix.length, 1);
    resultMatrix.matrix = normalizedMatrix;
    return resultMatrix;
  }

  hasConverged(previousMatrix, currentMatrix, tolerance = 1e-9) {
    const difference = math.subtract(previousMatrix, currentMatrix);
    const norm = math.norm(difference);
    return norm < tolerance;
  }
}

module.exports = AHP;
