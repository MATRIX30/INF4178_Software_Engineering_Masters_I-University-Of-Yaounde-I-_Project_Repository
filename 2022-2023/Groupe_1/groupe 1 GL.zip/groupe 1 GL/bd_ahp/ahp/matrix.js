const math = require('mathjs');

class Matrix {
  constructor(rows, cols, defaultValue = 0) {
    this.matrix = math.zeros(rows, cols).valueOf();
    if (defaultValue !== 0) {
      this.matrix = this.matrix.map((row) => row.map(() => defaultValue));
    }
  }

  getRows() {
    return math.size(this.matrix)[0];
  }

  getCols() {
    return math.size(this.matrix)[1];
  }

  setValue(row, col, value) {
    this.matrix[row][col] = value;
  }

  getValue(row, col) {
    return this.matrix[row][col];
  }

  add(matrix) {
    if (this.getRows() === matrix.getRows() && this.getCols() === matrix.getCols()) {
      const result = math.add(this.matrix, matrix.matrix);
      const newMatrix = new Matrix(this.getRows(), this.getCols());
      newMatrix.matrix = result.valueOf();
      return newMatrix;
    } else {
      throw new Error('Matrix dimensions are not compatible for addition.');
    }
  }

  multiply(matrix) {
    if (this.getCols() === matrix.getRows()) {
      const result = math.multiply(this.matrix, matrix.matrix);
      const newMatrix = new Matrix(this.getRows(), matrix.getCols());
      newMatrix.matrix = result.valueOf();
      return newMatrix;
    } else {
      throw new Error('Matrix dimensions are not compatible for multiplication.');
    }
  }

  transpose() {
    const result = math.transpose(this.matrix);
    const newMatrix = new Matrix(this.getCols(), this.getRows());
    newMatrix.matrix = result.valueOf();
    return newMatrix;
  }
}

module.exports = Matrix;
