# SmallholderFarmers
 Gestion des cultures : Développer un module qui permet aux agriculteurs de gérer leurs cultures, y compris la planification des cultures, le suivi de l'utilisation des intrants agricoles, la gestion des rendements, la gestion des ravageurs et des maladies, ainsi que la prévision des récoltes.
clone the project in your local repository 
excute npm init --yes
install the dependances 
npm i
start the server npm start listing in port:3001
