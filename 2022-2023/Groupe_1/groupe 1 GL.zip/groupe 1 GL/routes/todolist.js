const express = require("express");

const router = express.Router();
const todolisteController = require("../controllers/todolist");
router.get("/", todolisteController.view);

router.post("/add", todolisteController.store)

module.exports = router;