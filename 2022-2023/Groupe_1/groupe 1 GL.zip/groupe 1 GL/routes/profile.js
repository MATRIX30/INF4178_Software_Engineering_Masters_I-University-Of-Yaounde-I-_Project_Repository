const express = require("express");

const profileController = require("../controllers/profile")
const router = express.Router();


router.get("/", profileController.profile);
router.get("/add/:id", profileController.view);
router.post("/add/:id", profileController.update);

module.exports = router;
